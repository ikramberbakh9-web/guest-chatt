const socket = io();

// ===== GET USERNAME FROM URL =====
const params = new URLSearchParams(window.location.search);
const username = params.get("username");

if (!username) {
  window.location.href = "/";
}

// ===== DOM ELEMENTS =====
const usersList = document.getElementById("users");
const messagesDiv = document.getElementById("messages");
const messageInput = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");

const chatUsername = document.getElementById("chat-username");
const chatAvatar = document.getElementById("chat-avatar");
const tabsDiv = document.getElementById("tabs");

// ===== STATE =====
let currentChatUser = null;
let chats = {}; // { user: [messages] }

// ===== CONNECT =====
socket.emit("join", username);

// ===== USERS LIST =====
socket.on("users", (users) => {
  usersList.innerHTML = "";

  users.forEach((user) => {
    if (user === username) return;

    const li = document.createElement("li");
    li.textContent = user;
    li.onclick = () => openChat(user);
    usersList.appendChild(li);
  });
});

// ===== OPEN CHAT =====
function openChat(user) {
  currentChatUser = user;

  // ✅ تحديث الهيدر
  chatUsername.textContent = user;
  chatAvatar.textContent = user[0].toUpperCase();

  // إنشاء التاب إذا لم يكن موجود
  if (!document.getElementById(`tab-${user}`)) {
    const tab = document.createElement("div");
    tab.className = "tab active";
    tab.id = `tab-${user}`;
    tab.textContent = user;
    tab.onclick = () => openChat(user);
    tabsDiv.appendChild(tab);
  }

  renderMessages();
}

// ===== RENDER MESSAGES =====
function renderMessages() {
  messagesDiv.innerHTML = "";

  if (!currentChatUser || !chats[currentChatUser]) return;

  chats[currentChatUser].forEach((msg) => {
    const div = document.createElement("div");
    div.className = msg.from === username ? "message me" : "message other";
    div.innerHTML = `<strong>${msg.from}:</strong> ${msg.text}`;
    messagesDiv.appendChild(div);
  });

  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

// ===== SEND MESSAGE =====
function sendMessage() {
  const text = messageInput.value.trim();
  if (!text || !currentChatUser) return;

  const msg = {
    from: username,
    to: currentChatUser,
    text,
  };

  socket.emit("privateMessage", msg);

  if (!chats[currentChatUser]) chats[currentChatUser] = [];
  chats[currentChatUser].push(msg);

  messageInput.value = "";
  renderMessages();
}

// زر الإرسال
sendBtn.addEventListener("click", sendMessage);

// Enter للإرسال
messageInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendMessage();
});

// ===== RECEIVE MESSAGE =====
socket.on("privateMessage", (msg) => {
  const otherUser = msg.from === username ? msg.to : msg.from;

  if (!chats[otherUser]) chats[otherUser] = [];
  chats[otherUser].push(msg);

  if (currentChatUser === otherUser) {
    renderMessages();
  }
});
