const input = document.getElementById('username');
const btn = document.querySelector('#login button');

function connect() {
  const username = input.value.trim();
  if (!username) {
    alert('Please enter a username');
    return;
  }
  // إرسال اسم المستخدم كـ query parameter
  window.location.href = `chat.html?username=${encodeURIComponent(username)}`;
}

// الضغط على الزر
btn.addEventListener('click', connect);

// الضغط على Enter
input.addEventListener('keydown', function(e) {
  if (e.key === 'Enter') {
    connect();
  }
});
