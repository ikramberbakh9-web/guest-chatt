const { getUsers, getUserSocket } = require("./model");

// Broadcast list of online users to all connected clients
function broadcastUsers() {
  const data = JSON.stringify({ type: "users", users: getUsers() });
  getUsers().forEach(username => {
    const ws = getUserSocket(username);
    if (ws.readyState === ws.OPEN) {
      ws.send(data);
    }
  });
}

// Send private message
function sendPrivate(from, to, text) {
  const target = getUserSocket(to);
  if (target && target.readyState === target.OPEN) {
    target.send(JSON.stringify({ type: "private", from, text }));
  }
}

module.exports = { broadcastUsers, sendPrivate };
