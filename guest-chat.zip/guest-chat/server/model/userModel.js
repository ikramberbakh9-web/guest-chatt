// إدارة المستخدمين
class UserModel {
  constructor() {
    this.users = new Map(); // username -> ws
  }

  addUser(username, ws) {
    this.users.set(username, ws);
  }

  removeUser(username) {
    this.users.delete(username);
  }

  getUser(username) {
    return this.users.get(username);
  }

  getAllUsers() {
    return Array.from(this.users.keys());
  }
}

module.exports = new UserModel();
