// Model: users and their WebSocket connections
const users = new Map(); // username -> ws

function addUser(username, ws) {
  users.set(username, ws);
}

function removeUser(username) {
  users.delete(username);
}

function getUsers() {
  return Array.from(users.keys());
}

function getUserSocket(username) {
  return users.get(username);
}

module.exports = { addUser, removeUser, getUsers, getUserSocket };
