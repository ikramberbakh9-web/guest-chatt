const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Serve public files
app.use(express.static(path.join(__dirname, "../public")));

let users = new Map(); // username -> ws

wss.on("connection", (ws) => {
  ws.on("message", (data) => {
    const msg = JSON.parse(data);

    if (msg.type === "join") {
      ws.username = msg.username;
      users.set(msg.username, ws);
      broadcastUsers();
      return;
    }

    if (msg.type === "private") {
      const target = users.get(msg.to);
      if (target) {
        // رسالة للمستلم
        target.send(JSON.stringify({
          type: "private",
          from: ws.username,
          text: msg.text
        }));
        // رسالة للمرسل (لإظهارها عنده)
        ws.send(JSON.stringify({
          type: "private",
          from: ws.username,
          to: msg.to,
          text: msg.text
        }));
      }
    }
  });

  ws.on("close", () => {
    users.delete(ws.username);
    broadcastUsers();
  });
});

function broadcastUsers() {
  const data = JSON.stringify({
    type: "users",
    users: Array.from(users.keys())
  });

  users.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(data);
    }
  });
}

server.listen(3000, () => {
  console.log("✅ Server running on http://localhost:3000");
});
