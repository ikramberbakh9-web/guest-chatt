const WebSocket = require("ws");
const userModel = require("../model/userModel");

class ChatController {
  constructor(server) {
    this.wss = new WebSocket.Server({ server });
    this.init();
  }

  init() {
    this.wss.on("connection", (ws) => {
      ws.on("message", (data) => this.handleMessage(ws, data));
      ws.on("close", () => this.handleDisconnect(ws));
    });
  }

  handleMessage(ws, data) {
    const msg = JSON.parse(data);

    if (msg.type === "join") {
      ws.username = msg.username;
      userModel.addUser(msg.username, ws);
      this.broadcastUsers();
      return;
    }

    if (msg.type === "private") {
      const target = userModel.getUser(msg.to);
      if (target) {
        target.send(JSON.stringify({
          type: "private",
          from: ws.username,
          text: msg.text
        }));

        ws.send(JSON.stringify({
          type: "private",
          from: ws.username,
          to: msg.to,
          text: msg.text
        }));
      }
    }
  }

  handleDisconnect(ws) {
    userModel.removeUser(ws.username);
    this.broadcastUsers();
  }

  broadcastUsers() {
    const data = JSON.stringify({
      type: "users",
      users: userModel.getAllUsers()
    });

    userModel.getAllUsers().forEach(username => {
      const ws = userModel.getUser(username);
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  }
}

module.exports = ChatController;
